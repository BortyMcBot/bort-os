# ROUTING_STATE.md

Generated: Mar 05, 2026, 6:00 AM (America/Phoenix)

## Global configured defaults
- primary: openai-codex/gpt-5.2-codex
- fallbacks: openai-codex/gpt-5.2, openrouter/nvidia/nemotron-nano-9b-v2:free

## Workspace routing categories (from os/model-routing.js ROUTES)

### code_ops
- openai-codex/gpt-5.3-codex
- openai-codex/gpt-5.2-codex
- openai-codex/gpt-5.2
- openrouter/nvidia/nemotron-nano-9b-v2:free

### lightweight
- openai-codex/gpt-5.2-codex
- openai-codex/gpt-5.2
- openai-codex/gpt-5.3-codex
- openrouter/nvidia/nemotron-nano-9b-v2:free

### research_web
- openai-codex/gpt-5.3-codex
- openai-codex/gpt-5.2-codex
- openai-codex/gpt-5.2
- openrouter/nvidia/nemotron-nano-9b-v2:free

### social_drafting
- openai-codex/gpt-5.2-codex
- openai-codex/gpt-5.2
- openai-codex/gpt-5.3-codex
- openrouter/nvidia/nemotron-nano-9b-v2:free

### spec_large
- openai-codex/gpt-5.3-codex
- openai-codex/gpt-5.2-codex
- openai-codex/gpt-5.2
- openrouter/nvidia/nemotron-nano-9b-v2:free

### default
- openai-codex/gpt-5.2-codex
- openai-codex/gpt-5.2
- openai-codex/gpt-5.3-codex
- openrouter/nvidia/nemotron-nano-9b-v2:free

## Notes
- This file is regenerated automatically; manual edits may be overwritten.

