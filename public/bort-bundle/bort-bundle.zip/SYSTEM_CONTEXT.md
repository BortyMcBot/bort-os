# SYSTEM_CONTEXT.md

Generated: Feb 25, 2026 • 9:20 AM (America/Phoenix)

## Source of Truth Maintenance Protocol

The `project_source/` directory is the **canonical “Source of Truth”** for this project’s externally-shareable context.

### What BORT does (automatic)

- Preflight path runs **drift check only** via:
  - `/root/.openclaw/workspace/scripts/run-project-source-check.mjs`
  - `/root/.openclaw/workspace/scripts/arch-drift-check.mjs`
- Scheduled refresh (twice daily) updates generated docs only (no export):
  - `/root/.openclaw/workspace/scripts/refresh-project-source.mjs`
- Export is **on request** and always refreshes first via:
  - `/root/.openclaw/workspace/scripts/export-bort-source.sh`
- Export writes:
  1) `/root/.openclaw/workspace/project_source/EXPORT_LATEST.md`
  2) `/root/.openclaw/workspace/dist/bort_source_bundle.tgz`
  3) `[BORT_SOURCE_UPDATE]` notification block + memory/to_upload.md entry

### What Bryan should do when notified

When you see a `[BORT_SOURCE_UPDATE]` notification:

1) Upload `/root/.openclaw/workspace/project_source/EXPORT_LATEST.md` into the ChatGPT Project (or any external thread that needs to stay accurate).
2) Treat `EXPORT_LATEST.md` as the authoritative snapshot for that update.

### Manual export

You can force an export at any time:

```bash
node /root/.openclaw/workspace/scripts/export-project-source.mjs --force
```

### Canonical files (fixed order)

- `FILE_INDEX.md`
- `SYSTEM_CONTEXT.md`
- `STATE_OF_BORT.md`
- `PROMPT_TEMPLATES.md`
- `HAT_STATE.md`
- `ARCHITECTURE_SUMMARY.md`
- `ROUTING_STATE.md`
- `OPERATIONS_STATE.md`
- `CHANGELOG_AUTOGEN.md` (export includes last 200 lines only)
- `SKILL_REGISTRY.md`
- `PROJECTS_ACTIVE.md`
- `PROMPT_ANTIPATTERNS.md`
- `HAT_OS_RESOLUTION.md`
- `CLAUDE_SESSION_OPENER.md`

## Task Envelope & Hat Enforcement

This repository includes a workspace-level preflight enforcement layer:

- `/root/.openclaw/workspace/os/preflight.js`

### Required envelope fields

The preflight layer expects the Task Envelope to include all fields in `REQUIRED_FIELDS`:

- `hat`
- `intent`
- `taskType`
- `taskSize`
- `risk`
- `dataSensitivity`
- `externalStateChange`
- `identityContext`
- `actions`
- `approvalNeeded`

Source:
- `/root/.openclaw/workspace/os/preflight.js` lines 48–59

### Hat allowlist

Only these hats are defined in the preflight allowlist:

- `inbox`
- `web`
- `resale`
- `ops-core`
- `autonomous`

Source:
- `os/preflight.js` lines 25–46

### Identity context rules

Each hat defines allowed identity contexts, and preflight rejects envelopes that violate them.

Source:
- `os/preflight.js` lines 136–145

### Approval gating

If `externalStateChange === true`, preflight requires `approvalNeeded === true`.

Source:
- `os/preflight.js` lines 162–165

### Per-hat action enforcement

preflight.js enforces allowedCommands and allowedSkills per hat via action tags in the Task Envelope.
Actions not in the hat's allowedCommands or allowedSkills will be rejected at preflight.

### Policy override

preflight.js supports policyOverride and policyOverrideReason fields in the Task Envelope for authorized override scenarios.

### High-sensitivity output suppression

`os/preflight.js` implements deterministic high-sensitivity output suppression using explicit blocklist patterns.
If a blocklist match occurs, the caller must suppress output and show only a pointer message.

Source:
- `os/preflight.js` lines 185–233

### Conversational “Hat: os” is aliased to ops-core — RESOLVED 2026-03-03

Conversational directives that label tasks as `Hat: os` are now handled correctly.
`os/preflight.js` defines `HAT_ALIASES = { os: 'ops-core' }` — envelopes with `hat=os`
are resolved to `ops-core` before allowlist validation and will pass preflight.

Source:

- `os/preflight.js` lines 138–139 (HAT_ALIASES mapping)

No action required. See also: `HAT_OS_RESOLUTION.md` (Option A implemented) and
`PROMPT_ANTIPATTERNS.md` Antipattern 1 (status: RESOLVED).

## Documentation Integrity & Drift Enforcement

This system aims to prevent **silent documentation drift** between live implementation and `project_source/`.

### Drift classification

Each run classifies detected changes as one of:

- **cosmetic**: formatting/whitespace-only changes in canonical markdown
- **structural**: additions/removals of top-level directories under `/root/.openclaw/workspace/`
- **behavioral (HIGH severity)**: changes to key implementation files or extracted architectural invariants

Classification is enforced by:

- `/root/.openclaw/workspace/scripts/arch-drift-check.mjs`

### Behavioral drift (HIGH severity) rules

At minimum, HIGH severity drift triggers if any of the following change:

- Key implementation files:
  - `os/preflight.js`
  - `os/model-routing.js`
- Extracted architectural invariants:
  - Hat allowlist
  - Route categories or ordering
  - Default fallback model

### Enforcement behavior

- **If HIGH severity behavioral drift is detected:**
  - BORT emits a `[BORT_ARCH_DRIFT]` notification block.
  - BORT appends a “Drift Report” section to `CHANGELOG_AUTOGEN.md`.
  - BORT **does not** automatically rewrite canonical docs.
  - BORT **does not** automatically generate a new `EXPORT_LATEST.md` bundle.
  - Bryan must explicitly confirm before documentation reconciliation occurs.

- **If cosmetic or structural drift is detected:**
  - Normal export behavior is allowed (hashing + `EXPORT_LATEST.md` generation + `[BORT_SOURCE_UPDATE]` notification).

## Quality rule (no stubs)

Canonical files in `project_source/` must not remain as `TODO` placeholders.
Stubs create "paper truth" that can mislead external threads.

## Collaborative Development Convention

All commits to the bort-os repo must be authored by BortyMcBot[bot] via the GitHub App.
Bryan's personal GitHub account (NewWorldOrderly) must never appear in repo history.

Branch naming convention:
- claude/ — branches created by Claude Code during Bryan's dev sessions
- bort/ — branches created by Bort in autonomous or ops-core tasks

### PR Review & Merge Policy
All code changes from Claude Code sessions flow through PRs. Bort reviews and merges autonomously.

Workflow:
1. Claude Code pushes a claude/* branch and opens a PR via the BortyMcBot GitHub App
2. Bort reviews PRs at 7am and 6pm Phoenix, or on demand via Telegram /pr-review
3. Approved PRs are squash-merged to main automatically
4. Flagged PRs receive a review comment and Bryan is notified via Telegram

Auto-reject triggers (Bort requests changes, no merge):
- Author is NewWorldOrderly (not via GitHub App)
- project_source/*.md touched directly
- .arch_drift_baseline.json touched directly
- Branch not prefixed claude/ or bort/
- Secret/token patterns detected in diff

Escalate to Bryan triggers (Bort requests changes + Telegram notification):
- Removals in os/preflight.js
- Any change to os/hat-profiles.json
- Additions in os/model-routing.js
- Diff exceeds 500 lines

Safe zones for auto-merge:
- scripts/, integrations/, hats/, docs/

Post-merge behavior:
- Bort sends Telegram confirmation to Bryan (chat ID 8374853956)
- Bort does not delete branches post-merge
- Bort queues a drift baseline rebuild if os/preflight.js or os/model-routing.js were changed

Ownership zones:
- os/preflight.js, os/model-routing.js, os/hat-profiles.json → Bryan+Claude Code
- project_source/*.md, .arch_drift_baseline.json → Bort only
- scripts/, integrations/, hats/ → either, coordination preferred
